import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { MailboxserviceService } from '../mailboxservice.service';

@Component({
  selector: 'app-send-receivestats',
  templateUrl: './send-receivestats.component.html',
  styles: []
})
export class SendReceivestatsComponent implements OnInit {
  sendrecstats: any = [];
  SendMsgListData: any = [];
  RecMsgListData: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  totaluser: any;
  totalsenmsg: any;
  totalrecmsg: any;

  constructor(private service: MailboxserviceService, private route: Router) {

  }

  ngOnInit() {
    this.service.GetsendreceiveStats().subscribe(k => {
      this.sendrecstats = k;
      this.totaluser = this.sendrecstats.length;
      this.totalsenmsg = this.sendrecstats.map(t => t.cn1).reduce((a, value) => a + value, 0);
      this.totalrecmsg = this.sendrecstats.map(t => t.cn2).reduce((a, value) => a + value, 0);

      this.dtTrigger.next();
    });
    this.dtOptions = {
      pageLength: 10, pagingType: 'full_numbers'
    };
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  SendMsgList(userId) {
    this.route.navigate(['/msgdetails', userId, 'S']);
  }
  ReceiveMsgList(userId) {
    this.route.navigate(['/msgdetails', userId, 'R']);
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

}
