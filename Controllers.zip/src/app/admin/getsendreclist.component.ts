import { Component, OnInit } from '@angular/core';
import { MailboxserviceService } from '../mailboxservice.service';
import { ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-getsendreclist',
  templateUrl: './getsendreclist.component.html',
  styles: []
})
export class GetsendreclistComponent implements OnInit {
  flag: string = "";
  userId: any = "";
  userName: string = "";
  senderorReceiver: any = "";
  type: string = "";

  SendMsgListData: any = [];
  RecMsgListData: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  constructor(private service: MailboxserviceService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.flag = params.get('flag');
      this.userId = params.get('uid');

      if (this.flag == 'S') {
        var message = { 'userId': this.userId, 'flag': 'S' };
        this.service.GetSendMsgList(message).subscribe(k => {
          this.SendMsgListData = k;
          this.type = "Send";
          this.senderorReceiver = "Posted To";
          this.dtTrigger.next();

        });

      }
      else if (this.flag == 'R') {
        var message = { 'userId': this.userId, 'flag': 'R' };
        this.service.GetSendMsgList(message).subscribe(k => {
          this.SendMsgListData = k;
          this.type = "Receive";
          this.senderorReceiver = "Received From";
          this.dtTrigger.next();

        });
      }

      this.service.UserLastLogin(this.userId).subscribe(k => {
        this.userName = k['officeName'];
      });
      this.dtOptions = {
        pageLength: 10, pagingType: 'full_numbers'
      };
    });

  }
}