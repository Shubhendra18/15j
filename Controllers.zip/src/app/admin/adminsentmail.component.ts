import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';


@Component({
  selector: 'app-adminsentmail',
  templateUrl: './adminsentmail.component.html',
  styles: []
})
export class AdminsentmailComponent implements OnInit {
  private allmails: any = [];
  SelectedIDs: any = [];
  allmailtotrash: boolean = false;
  decryptnew = localStorage.getItem("Token").toString();
  Rid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);

  constructor(private service: MailboxserviceService, private toastr: ToastrService) { }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.allMailFromSent(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }
  Refresh() {
    this.ngOnInit();
  }
  trackByFn(index: number, item) {
    return index;
  }
}
