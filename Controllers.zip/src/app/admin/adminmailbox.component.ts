import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-adminmailbox',
  templateUrl: './adminmailbox.component.html',
  styles: []
})
export class AdminmailboxComponent implements OnInit {
  private allmails: any = [];
  SelectedIDs: any = [];
  i: number = 0;
  allmailtotrash: boolean = false;
  decryptnew = localStorage.getItem("Token").toString();
  Rid = CryptoJS.AES.decrypt(this.decryptnew.trim(), "at").toString(CryptoJS.enc.Utf8);
  isimportant = "text-dark";
  isSelected: boolean = false;
  //p: number = 1;
  names: any;
  selectAll = false;
  baseurl: any = "";

  p: number = 1;
  total: number = 0;
  itemPerPage: number = 3;
  pageChanged($event): void {
    this.p = $event;
    this.ngOnInit();

  }
  totalRec: number;
  page: number = 1;


  constructor(private service: MailboxserviceService, private toastr: ToastrService) {
    this.baseurl = this.service.getbaseurl();

  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    this.service.getmail(this.Rid).subscribe(k => {
      this.allmails = k;
    });
    // var datat = { 'PageNumber': 1, 'ItemsPerPage': 10, 'Rid': this.Rid };
    // this.service.getmail(datat).subscribe(k => {
    //   this.allmails = k['data'];
    //   this.total = k['Total'];
    // });
  }


  checkAll(ev) {
    this.allmails.forEach(x => x.state = ev.target.checked);
    this.allmailtotrash = (ev.currentTarget.checked);

  }
  isAllChecked() {
    return this.allmails.every(_ => _.state);
  }
  deleteSelected() {
    if (this.allmailtotrash == true) {
      var moveToTrash = { 'Rid': this.Rid, 'flag': 0 };
      this.service.allMailsmoveToTrash(moveToTrash).subscribe(k => {
        if (k == "success") {
          this.toastr.success('Inbox is Empty!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Trash!', 'Error');
        }
      });
    }
    else {
      this.service.moveToTrash(this.SelectedIDs).subscribe(k => {
        if (k == "Success") {
          this.toastr.info('Moved To Trash!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Trash!', 'Error');
        }
      });
    }
  }
  archivedSelected() {
    if (this.allmailtotrash == true) {
      var moveToArchive = { 'Rid': this.Rid, 'flag': 0 };
      this.service.allMailsmoveToArchive(moveToArchive).subscribe(k => {
        if (k == "success") {
          this.toastr.success('Moved To Archived!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Archived!', 'Error');
        }
      });
    }
    else {
      this.service.moveToArchive(this.SelectedIDs).subscribe(k => {
        if (k == "Success") {
          this.toastr.info('Moved To Archived!', 'Success');
          this.ngOnInit();
        }
        else {
          this.toastr.error('Failed to Moved To Archived!', 'Error');
        }
      });
    }
  }
  FieldsChange(event: any, mailId) {
    this.SelectedIDs.push(mailId);
  }
  alltotrash(values: any) {
    this.allmailtotrash = (values.currentTarget.checked);
  }
  Refresh() {
    this.ngOnInit();
  }
  markasImportant(mailId) {
    this.service.moveToImportant(mailId).subscribe(k => {
      if (k == "success") {
        this.toastr.success('Moved To Important!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Archived!', 'Error');
      }
    });
  }
  trackByFn(index: number, item) {
    return index;
  }
}
