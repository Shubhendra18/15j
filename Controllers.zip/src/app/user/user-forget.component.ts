
import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomValidators } from '../common/custom-validators';

@Component({
  selector: 'app-user-forget',
  templateUrl: './user-forget.component.html',
  styleUrls: ['./user-login.component.css']

})
export class UserForgetComponent implements OnInit {
  divforget = false;
  divotp = true;
  divreset = true;
  MobileNo: string = '';
  userId: number;
  public frmreset: FormGroup;
  public loading = false;

  constructor(private service: MailboxserviceService, private router: Router, private fb: FormBuilder) {
    this.frmreset = this.createresetForm();

  }

  ngOnInit() {
  }
  sendotp(mobileNo) {
    this.loading = true;
    
    this.service.forgetPassword(mobileNo).subscribe((data: any) => {
      this.MobileNo = mobileNo;
      if (data.displayMessage.type = "s") {
        this.loading = false;

        Swal.fire({
          icon: 'success',
          title: 'OTP Sent Successfully',
          text: data.displayMessage.message,
        })
        this.divforget = true;
        this.divotp = false;
        this.divreset = true;
      }
      else {
        this.divforget = false;
        this.divotp = true;
        this.divreset = true;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.loading = false;

        Swal.fire({
          icon: 'warning',
          title: 'warning',
          text: err.error.message,
        })
      };
    });
  }
  otpverify(OTP) {
    this.loading = true;

    this.service.otpVerification(this.MobileNo, OTP).subscribe((data: any) => {
      if (data.verification == "verified") {
        this.loading = false;

        this.userId = data.userId;
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'OTP Verified Successfully',
        });
        this.divforget = true;
        this.divotp = true;
        this.divreset = false;
      }
    }, (err: HttpErrorResponse) => {
      if (err.status === 400) {
        this.loading = false;

        Swal.fire({
          icon: 'warning',
          title: 'warning',
          text: err.error.message,
        })
        this.divforget = true;
        this.divotp = false;
        this.divreset = true;
      };
    });
  }
  resetpassword() {
    this.loading = true;

    const password = this.frmreset.get('password');
    console.log(password)
    this.service.changePassword(this.userId, password.value).subscribe(k => {
      if (k == "success") {
        this.loading = false;

        Swal.fire({
          title: 'Password Changed',
          text: "Password Changed Successfully!",
          icon: 'success',
          confirmButtonColor: '#3085d6',
          confirmButtonText: 'Go Back To Login!'
        }).then((result) => {
          if (result.value) {
            this.loading = false;

            this.router.navigate(['/login']);
          }
        })
      }
    })
  }
  backtoForget() {
    this.divforget = false;
    this.divotp = true;
    this.divreset = true;
  }
  createresetForm(): FormGroup {
    return this.fb.group(
      {
        password: [
          null,
          Validators.compose([
            Validators.required,
            CustomValidators.patternValidator(/\d/, {
              hasNumber: true
            }),
            CustomValidators.patternValidator(/[A-Z]/, {
              hasCapitalCase: true
            }),
            CustomValidators.patternValidator(/[a-z]/, {
              hasSmallCase: true
            }),
            CustomValidators.patternValidator(
              /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/,
              {
                hasSpecialCharacters: true
              }
            ),
            Validators.minLength(8)
          ])
        ],
        confirmPassword: [null, Validators.compose([Validators.required])],
        userId: []
      },
      {
        validator: CustomValidators.passwordMatchValidator
      }
    );
  }
}
