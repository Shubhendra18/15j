import { Component } from '@angular/core';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-user-reset',
  templateUrl: './user-reset.component.html',
  styles: []
})
export class UserResetComponent {
  title = 'EncryptionDecryptionSample';

  plainText: string;
  encryptText: string;
  conversionEncryptOutput: string;
  conversionDecryptOutput: string;

  constructor() {
  }
  //method is used to encrypt and decrypt the text  
  convertText(conversion: string) {
    if (conversion == "encrypt") {
      this.conversionEncryptOutput = CryptoJS.AES.encrypt(this.plainText.trim(),"ut").toString();
    }
    else {
      this.conversionDecryptOutput = CryptoJS.AES.decrypt(this.encryptText.trim(),"ut").toString(CryptoJS.enc.Utf8);

    }
  }
}  