import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MailboxserviceService } from '../mailboxservice.service';
import * as CryptoJS from 'crypto-js';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-sentmail-des',
  templateUrl: './sentmail-des.component.html',
  styles: []
})
export class SentmailDesComponent implements OnInit {
  decrypt = localStorage.getItem("userToken").toString();
  Rid = CryptoJS.AES.decrypt(this.decrypt.trim(), "ut").toString(CryptoJS.enc.Utf8);
  private maildetails: any = {};
  attachments: any = [];
  attachmentcount: number = 0;

  constructor(private service: MailboxserviceService, private route: ActivatedRoute) { }
  ngOnInit() {
    
    this.route.paramMap.subscribe(params => {
      var sendMailDes = { "userId": this.Rid, "messageid": params.get('messageid') };
      this.service.GetSentMailDetails(sendMailDes).subscribe(k => {
        this.maildetails = k;
      })
      var mailDes = { "mailId": params.get('messageid'), "rid": this.Rid };
      this.service.getSentattachments(mailDes).subscribe(k => {
        this.attachments = k;
        this.attachmentcount = this.attachments.length;
      })
    });
  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  Download(attachment) {
    this.service.DownloadAttachments(attachment).subscribe(k => {
      saveAs(k, attachment);
    });
  }
}
