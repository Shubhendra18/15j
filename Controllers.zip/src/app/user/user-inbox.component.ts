import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { MailboxserviceService } from '../mailboxservice.service';
import { HttpErrorResponse } from '@angular/common/http';
import * as CryptoJS from 'crypto-js';
import { empty } from 'rxjs';

declare var $;

@Component({
  selector: 'app-user-inbox',
  templateUrl: './user-inbox.component.html',
  styles: []
})
export class UserInboxComponent implements OnInit {
  private allmails: any = [];
  SelectedIDs: any = [];
  i: number = 0;
  allmailtotrash: boolean = false;
  decrypt = localStorage.getItem("userToken").toString();
  Rid = CryptoJS.AES.decrypt(this.decrypt.trim(), "ut").toString(CryptoJS.enc.Utf8);

  isimportant = "text-dark";
  p: number = 1;

  profilepic = "";
  baseurl: any = "";
  selectAll: any;

  /***** */
  total: number = 0;
  itemPerPage: number = 3;
  pageChanged($event): void {
    this.p = $event;
    this.ngOnInit();
  }
  totalRec: number;
  page: number = 1;
  //**** */
  constructor(private service: MailboxserviceService, private toastr: ToastrService) {
    this.baseurl = this.service.getbaseurl();
  }
  getShortName(fullName) {
    if (fullName != null) {
      return fullName.split(' ').map(n => n[0]).join('');
    }
  }
  ngOnInit() {
    var datat = { 'PageNumber': 1, 'ItemsPerPage': 50, 'Rid': this.Rid };
    this.service.getmail(datat).subscribe(k => {
      this.allmails = k['data'];
      this.total = k['Total'];

    });
    // this.service.getmail(this.Rid).subscribe(k => {
    //   this.allmails = k;
    // });
  }
  //******* */
  checkAll() {
    for (let index = 0; index < this.allmails.length; index++) {
      this.allmails[index].state = this.selectAll
    }
    this.FieldsChange();
  }
  isAllChecked() {
    this.selectAll = this.allmails.every(function (item: any) {
      return item.state == true;
    })
    this.FieldsChange();
  }
  FieldsChange() {
    this.SelectedIDs = [];
    for (let index = 0; index < this.allmails.length; index++) {
      if (this.allmails[index].state)
        this.SelectedIDs.push(this.allmails[index].mailId);
    }
    this.SelectedIDs = JSON.stringify(this.SelectedIDs);
  }

  //******* */
  deleteSelected() {
    this.service.moveToTrash(this.SelectedIDs).subscribe(k => {
      if (k == "Success") {
        this.toastr.info('Moved To Trash!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Trash!', 'Error');
      }

    });
  }
  archivedSelected() {
    this.service.moveToArchive(this.SelectedIDs).subscribe(k => {
      if (k == "Success") {
        this.toastr.info('Moved To Archived!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Archived!', 'Error');
      }
    });
  }


  alltotrash(values: any) {
    this.allmailtotrash = (values.currentTarget.checked);
  }
  Refresh() {
    this.ngOnInit();
    this.selectAll = "";

  }
  markasImportant(mailId) {
    this.service.moveToImportant(mailId).subscribe(k => {
      if (k == "success") {
        this.toastr.success('Moved To Important!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Archived!', 'Error');
      }
    });
  }
  trackByFn(index: number, item) {
    return index;
  }
}
