import { Component, OnInit, ElementRef, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
declare var $;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'MailBox';
  constructor(private elementRef: ElementRef, @Inject(DOCUMENT) private doc) {
  }

  ngOnInit() {

    // let link1: HTMLLinkElement = this.doc.createElement('link');
    // link1.setAttribute('rel', 'amphtml');
    // link1.setAttribute('href', '../assets/css/bootstrap.min.css');
    // this.doc.head.appendChild(link1);

    // let link: HTMLLinkElement = this.doc.createElement('link');
    // link.setAttribute('rel', 'amphtml');
    // link.setAttribute('href', '../assets/css/owl.carousel.css');
    // this.doc.head.appendChild(link);

  

    // var s1 = document.createElement("script");
    // s1.type = "text/javascript";
    // s1.src = "../assets/js/style-switcher.js";
    // this.elementRef.nativeElement.appendChild(s1);
  }

}

