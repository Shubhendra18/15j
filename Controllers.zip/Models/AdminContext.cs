﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MandiParishadWebApi.Filters;
using MandiParishadWebApi.Models;
namespace MandiParishadWebApi.Models
{
    public class AdminContext : DbContext
    {
        public AdminContext() : base("MandiContext")
        {

        }
        public List<GroupMaster> GetGroupMaster()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@grpID",Value=0},
                new SqlParameter {ParameterName="@gpName",Value=""},
                 };
            var sqlQuery = @"sp_getGroups @grpID,@gpName";
            var res = this.Database.SqlQuery<GroupMaster>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public AfterUserLogin UserLogin(string UserName)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userName",Value=UserName},
                new SqlParameter {ParameterName="@LastLoginIP",Value=Common.GetIPAddress()},

                 };
            var sqlQuery = @"sp_newAdminLogin @userName,@LastLoginIP";
            var res = this.Database.SqlQuery<AfterUserLogin>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public GetUserProfileInfo LastLoginInfo(Int64 userId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=userId},
                 };
            var sqlQuery = @"Sp_NewLastUserLoginInfo @userId";
            var res = this.Database.SqlQuery<GetUserProfileInfo>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public GetUserProfileInfo UpdateProfile(Int64 userId, string mobileNo, string Profilepic)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=userId},
                new SqlParameter {ParameterName="@mobileNo",Value=mobileNo},
                new SqlParameter {ParameterName="@profilepic",Value=Profilepic},
                 };
            var sqlQuery = @"Sp_NewUpdateProfileInfo @userId,@mobileNo,@profilepic";
            var res = this.Database.SqlQuery<GetUserProfileInfo>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public object AddUpdateGroupName(int transId, String GroupName, int UserId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@transId",Value=transId},
                new SqlParameter {ParameterName="@groupName",Value=GroupName},
                new SqlParameter {ParameterName="@userId",Value=UserId},
                 };
            var sqlQuery = @"sp_saveUpdateGroup @transId,@groupName,@userId";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public object DeleteGroup(int groupId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@transId",Value=groupId},
                 };
            var sqlQuery = @"sp_deleteGroup @transId";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public object AddUser(AddUser addUser)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@NAME_OF_OFFICES",Value=addUser.officeName},
                new SqlParameter {ParameterName="@PASSWORD1",Value=addUser.password},
                new SqlParameter {ParameterName="@groupID",Value=addUser.groupID},
                new SqlParameter {ParameterName="@recflag",Value="A"},
                new SqlParameter {ParameterName="@mobileNo",Value=addUser.mobileNo},
                 };
            var sqlQuery = @"Sp_NewAddUserMaster @NAME_OF_OFFICES,@PASSWORD1,@groupID,@recflag,@mobileNo";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public object GetUsersCount(int GroupId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupID",Value=GroupId}
                 };
            var sqlQuery = @"Proc_selectUserCount @groupID";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public object CheckUserNameOrMobile(ChkUserMobile chkUserMobile)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userOrMobile",Value=chkUserMobile.UserorMobile},
                new SqlParameter {ParameterName="@flag",Value=chkUserMobile.flag}
                 };
            var sqlQuery = @"SP_NewgetUserNameOrMobile @userOrMobile,@flag";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public List<UserByGroup> GetGroupUsers(int groupID)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupID",Value=groupID}
                 };
            var sqlQuery = @"Proc_selectUser @groupID";
            var res = this.Database.SqlQuery<UserByGroup>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public Int64 ComposeMail(int Priority, bool? SMS, string Subject, string Message, Int64 Sid, Int64 Rid, string msgid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@priority",Value=Priority},
                new SqlParameter {ParameterName="@sms",Value=SMS} ,
                new SqlParameter {ParameterName="@sub",Value=Subject} ,
                new SqlParameter {ParameterName="@msg",Value=Message},
                new SqlParameter {ParameterName="@sid",Value=Sid},
                new SqlParameter {ParameterName="@rid",Value=Rid},
                new SqlParameter {ParameterName="@messageid",Value=msgid}

                 };
            var sqlQuery = @"Sp_NewComposeMail @priority,@sms,@sub,@msg,@sid,@rid,@messageid";
            Int64 res = this.Database.SqlQuery<Int64>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<UserByGroup> GetGroupUsersforManage(int groupID)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupID",Value=groupID}
                 };
            var sqlQuery = @"Sp_NewselectUserByGroupForManage @groupID";
            var res = this.Database.SqlQuery<UserByGroup>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string updateUserMaster(UpdateuserModel model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=model.userId},
                new SqlParameter {ParameterName="@userName",Value=model.officeName},
                new SqlParameter {ParameterName="@mobileNo",Value=model.mobileNo},
                 };
            var sqlQuery = @"Sp_NewupdateUserMaster @userId,@userName,@mobileNo";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<LastLoginModel> GetlastloginReport()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupID",Value=0}
                 };
            var sqlQuery = @"sp_NewgetLastLoginReport @groupID";
            var res = this.Database.SqlQuery<LastLoginModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public object CheckGroupName(String groupName)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupName",Value=groupName}
                 };
            var sqlQuery = @"Sp_NewgetGroupName @groupName";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public List<SendAndReceiveModel> GetSendAndReceiveMsgs()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupId",Value=0}
                 };
            var sqlQuery = @"sp_NewgetSentAndReceivedStats @groupId";
            var res = this.Database.SqlQuery<SendAndReceiveModel>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<UsedUser> GetUsedUser()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupId",Value=0}
                 };
            var sqlQuery = @"Sp_NewuserUsedUser @groupId";
            var res = this.Database.SqlQuery<UsedUser>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<UsedUser> GetNotUsedUser()
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@groupId",Value=0}
                 };
            var sqlQuery = @"Sp_NewNotUsedUser @groupId";
            var res = this.Database.SqlQuery<UsedUser>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<UsedUser> GetPostedMessageRecord(int postedid, int searchType, String searchCriteria, DateTime fromDate, DateTime toDate)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@postedid",Value=postedid},
                new SqlParameter {ParameterName="@searchType",Value=searchType},
                new SqlParameter {ParameterName="@searchCriteria",Value=searchCriteria},
                new SqlParameter {ParameterName="@fromDate",Value=fromDate},
                new SqlParameter {ParameterName="@toDate",Value=toDate},
                 };
            var sqlQuery = @"sp_getPostedMessageRecord @postedid,@searchType,@searchCriteria,@fromDate,@toDate";
            var res = this.Database.SqlQuery<UsedUser>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public ActiveDeactiveRespnse ActiveDeactiveUser(ActiveDeactive activeDeactive)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=activeDeactive.userId},
                new SqlParameter {ParameterName="@recflag",Value=activeDeactive.recflag}
                 };
            var sqlQuery = @"sp_NewActivateDeactivate @userId,@recflag";
            ActiveDeactiveRespnse res = this.Database.SqlQuery<ActiveDeactiveRespnse>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<GetOfficeName> OfficeName()
        {
            var sqlQuery = @"Proc_selectOffice";
            var res = this.Database.SqlQuery<GetOfficeName>(sqlQuery).ToList();
            return res;
        }
        public List<ReportByOfficeName> ReportByOfficeName(Int64 userId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userId",Value=userId},
                 };
            var sqlQuery = @"Sp_NewMessageReport @userId";
            var res = this.Database.SqlQuery<ReportByOfficeName>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<ReportByOfficeName> ReportBysubject(string subject)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@subject",Value=subject},
                 };
            var sqlQuery = @"Sp_NewMessageReportbySubject @subject";
            var res = this.Database.SqlQuery<ReportByOfficeName>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public List<ReportByOfficeName> ReportByDate(ReportByDate date)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@sdate",Value=date.sdate},
                new SqlParameter {ParameterName="@edate",Value=date.edate},
                 };
            var sqlQuery = @"Sp_NewMessageReportbyDate @sdate,@edate";
            var res = this.Database.SqlQuery<ReportByOfficeName>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string BroadcastMsg(Int64 sid, Int64 rid, string broadid, string message, string sub, string pic)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@sid",Value=sid},
                new SqlParameter {ParameterName="@rid",Value=rid},
                new SqlParameter {ParameterName="@broadid",Value=broadid},
                new SqlParameter {ParameterName="@msg",Value=message},
                new SqlParameter {ParameterName="@sub",Value=sub},
                new SqlParameter {ParameterName="@pic",Value=pic}


                 };
            var sqlQuery = @"Sp_NewSendBroadCast @sid,@rid,@broadid,@msg,@sub,@pic";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<BroadCastMessage> ViewBroadcastmsg(Int64 rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rid",Value=rid}
                 };
            var sqlQuery = @"Sp_NewGetBroadcastMessage @rid";
            var res = this.Database.SqlQuery<BroadCastMessage>(sqlQuery, sqlParam).ToList();
            return res;
        }
        public string BroadcastmsgSeen(Int64 rowid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@rowid",Value=rowid}
                 };
            var sqlQuery = @"Sp_NewBroadcastSeen @rowid";
            var res = this.Database.SqlQuery<string>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<BroadCastMessageReport> BroadcastStats()
        {
            var sqlQuery = @"Sp_NewViewBroadcastStats";
            var res = this.Database.SqlQuery<BroadCastMessageReport>(sqlQuery).ToList();
            return res;
        }
        public List<GetSendMessageList> GetsendMsgList(GetSendMessage message)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userid",Value=message.userId},
                new SqlParameter {ParameterName="@flag",Value=message.flag}
                 };
            var sqlQuery = @"Sp_NewGetSentMessage @userid,@flag";
            var res = this.Database.SqlQuery<GetSendMessageList>(sqlQuery, sqlParam).ToList();
            return res;
        }
    }
}